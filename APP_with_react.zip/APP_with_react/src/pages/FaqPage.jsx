import Faq from "../components/Faq";

const FaqPage = () => {
  return (
    <div>
      <Faq />
    </div>
  );
};

export default FaqPage;
