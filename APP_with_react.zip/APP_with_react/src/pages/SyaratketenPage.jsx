import { Container, Row, Col } from "react-bootstrap";
import Faq from "../components/Faq";

const SyaratPage = () => {
  return (
    <div className="syaratketen-page">
      <div className="syaratketen min-vh-100">
        <Container>
          <Row>
            <Col>
              <h1 className="text-center fw-bold mb-2 animate__animated animate__fadeInUp animate__delay-1s">
                Syarat & Ketentuan
              </h1>
              <p className="text-center animate__animated animate__fadeInUp animate__delay-1s">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Delectus.
              </p>
            </Col>
          </Row>
          <Row className="pt-5">
            <Col>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Corrupti perspiciatis distinctio odit optio earum ipsum officia,
                inventore, quam quos aspernatur beatae deleniti aliquid aut.
                Sapiente quae aliquam veritatis minima, atque inventore porro
                labore temporibus nostrum repellat, soluta rem, veniam beatae
                quas deserunt cupiditate ipsam quasi.
              </p>
            </Col>
          </Row>
          <Row className="py-3">
            <Col>
              <h4 className="fw-bold">1. lorem</h4>
              <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                Voluptatibus quos ratione illo officiis perspiciatis accusantium
                ea tempore vitae consectetur facere veniam voluptatum,
                explicabo, accusamus nesciunt autem. Maxime tempora quod, fuga
                saepe consequatur nobis. Deserunt, odio consequatur. Excepturi
                maxime unde provident!
              </p>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore
                harum delectus doloremque architecto numquam minus doloribus,
                ipsam omnis aspernatur aut aliquam, vel nulla earum reiciendis
                est fugiat tempora, distinctio possimus.
              </p>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Consequuntur rerum expedita nobis, tempora doloribus cupiditate
                non iure quae ducimus officia! Sed quia explicabo quod dicta
                minus ab accusamus incidunt officia voluptatum obcaecati quam
                esse quaerat eos ducimus debitis assumenda reiciendis,
                consequatur dignissimos sapiente laudantium, maiores inventore
                fugiat ex. Nesciunt, nostrum!
              </p>
            </Col>
          </Row>
          <Row className="py-3">
            <Col>
              <h4 className="fw-bold">2. lorem</h4>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad modi
                suscipit hic ipsa esse minima eaque ea assumenda. Omnis corporis
                commodi at quam, dolorem animi eum ullam? Quaerat eaque porro
                obcaecati officiis suscipit culpa odit doloribus odio minus,
                similique reprehenderit, harum voluptas architecto. Nostrum,
                sint commodi obcaecati dicta eligendi cupiditate.
              </p>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil
                suscipit dolores autem delectus, cupiditate dolore pariatur
                reprehenderit a fugit quisquam, quaerat ex tenetur dignissimos
                sapiente quos? Iste blanditiis culpa omnis aut, illum alias
                numquam autem debitis, illo deserunt accusamus nobis eum
                recusandae hic est perspiciatis architecto ratione reprehenderit
                voluptatibus commodi quae laboriosam voluptatem. Laudantium
                nulla voluptate itaque voluptates, pariatur tenetur illo iste,
                illum, optio provident ipsa! Nesciunt voluptatibus dolor, modi
                provident mollitia delectus minus, saepe ipsam, aliquam odio
                laborum.
              </p>
            </Col>
          </Row>
          <Row className="py-3">
            <Col>
              <h4 className="fw-bold">3. lorem</h4>
              <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                Molestiae vitae, fugiat corporis libero neque et ex aliquid! Hic
                obcaecati illum commodi deserunt nisi dolores illo delectus,
                dolore enim, tenetur temporibus iste unde reiciendis minus alias
                quidem provident sint asperiores quia? Cumque est, neque ducimus
                illo suscipit qui. Qui molestiae quo nulla accusamus libero
                laboriosam architecto ipsa quas, omnis cupiditate tenetur earum
                vero ab eos recusandae rerum! Odit cumque enim laudantium eaque
                sed nemo, non cupiditate! Fuga doloremque nostrum fugit numquam
                modi, repudiandae rem eaque facere deserunt placeat!
              </p>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Veritatis ad molestias in aspernatur alias iste odio distinctio
                sequi, accusantium officiis ex ipsam dolores? Tempora dolores
                distinctio modi sit voluptatem praesentium ullam ex iure
                aperiam? Libero harum itaque possimus asperiores beatae tenetur
                cupiditate consequatur praesentium cumque consectetur
                voluptatum, recusandae est, eos sapiente fugit quas molestiae,
                voluptates nostrum. Totam quo nihil blanditiis voluptatum
                repellendus fugiat unde facilis porro eos omnis atque
                perspiciatis maxime corrupti beatae alias officiis earum,
                recusandae qui quaerat consequuntur ullam, temporibus cumque.
                Aspernatur in iste sunt facere, atque corrupti?
              </p>
            </Col>
          </Row>
          <Row className="py-3">
            <Col>
              <h4 className="fw-bold">4. lorem</h4>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Doloremque placeat vitae, commodi repudiandae nam tempora,
                voluptate ipsum deserunt suscipit blanditiis rem? Voluptatum
                dignissimos, excepturi voluptas necessitatibus reiciendis
                laborum sit harum esse, vero quas dolorem velit itaque,
                explicabo nisi placeat aperiam debitis nulla numquam. Architecto
                qui unde placeat soluta illum adipisci esse animi accusamus
                distinctio. Cumque doloremque assumenda incidunt voluptates
                officiis.
              </p>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit
                et ipsa, earum dolore aperiam voluptas fugiat! At, blanditiis.
                Ut ullam, eveniet debitis nam at aspernatur quibusdam, a modi
                cum quos laborum soluta accusamus? Eum.
              </p>
            </Col>
          </Row>
        </Container>
      </div>
      <Faq />
    </div>
  );
};

export default SyaratPage;
