import { Routes, Route } from "react-router-dom";

import Navbar from "./components/NavbarComp";
import Footer from "./components/FooterComp";

import HomePage from "./pages/HomePage";
import KelasPage from "./pages/KelasPage";
import FaqPage from "./pages/FaqPage";
import SyaratketenPage from "./pages/SyaratketenPage";
import TestimonialPage from "./pages/TestimonialPage";

function App() {
  return (
    <div>
      <Navbar />

      <Routes>
        <Route path="/" Component={HomePage} />
        <Route path="/kelas" Component={KelasPage} />
        <Route path="/testimonial" Component={TestimonialPage} />
        <Route path="/faq" Component={FaqPage} />
        <Route path="/syaratketen" Component={SyaratketenPage} />
      </Routes>

      <Footer />
    </div>
  );
}

export default App;
